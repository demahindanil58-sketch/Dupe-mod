package com.example.dupemod;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public class DupeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(
                ClientCommandManager.literal(".dupe").executes(ctx -> {
                    var player = ctx.getSource().getPlayer();
                    if (player == null) {
                        ctx.getSource().sendError(Text.literal("Command only in game!"));
                        return 0;
                    }

                    ItemStack offhandStack = player.getOffHandStack();
                    if (offhandStack.isEmpty()) {
                        player.sendMessage(Text.literal("\u00A7cTake an item in your offhand!"), false);
                        return 0;
                    }

                    ItemStack copy = offhandStack.copy();
                    player.getInventory().offerOrDrop(copy);

                    player.sendMessage(Text.literal("\u00A7aDuplicated: \u00A7f" + offhandStack.getName().getString()), false);
                    return Command.SINGLE_SUCCESS;
                })
            )
        );
    }
}
